const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const cors = require('cors');
const socketIo = require('socket.io');
const { exec } = require('child_process'); // Import the exec function from the child_process module
const find = require('find-process'); // Import the find-process package

const app = express();
const PORT = process.env.PORT || 4000; // Change to a different port

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// Nodemailer setup (use environment variables for sensitive info)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'ghumti36@gmail.com',
    pass: 'kdzo bpbg ohat nqht',
  },
});

// Endpoint to handle POST requests to /backend
app.post('/backend', (req, res) => {
  const { type } = req.body;

  switch (type) {
    case 'order':
      handleOrderInquiry(req.body, res);
      break;
    default:
      handleGeneralInquiry(req.body, res);
  }
});

function handleGeneralInquiry(formData, res) {
  const { name, contact, email, message } = formData;

  const mailOptions = {
    from: email,
    to: 'shresthaaaryan123@gmail.com',
    subject: 'General Feedback',
    text: `Name: ${name}\nContact: ${contact}\nEmail: ${email}\nMessage: ${message}`,
  };

  sendEmail(mailOptions, res);
}

function handleOrderInquiry(formData, res) {
  const { orderSize, arrivalTime, arrivalDate, numberOfPeople, otherDetails, email, phoneNumber } = formData;

  const mailOptions = {
    from: email,
    to: 'shresthaaaryan123@gmail.com',
    subject: 'New Order Inquiry',
    text: `Order Size: ${orderSize}\nArrival Time: ${arrivalTime}\nArrival Date: ${arrivalDate}\nNumber of People: ${numberOfPeople}\nOther Details: ${otherDetails}\nEmail: ${email}\nPhone Number: +61-${phoneNumber}`,
  };

  sendEmail(mailOptions, res);
}

function sendEmail(mailOptions, res) {
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
      res.status(500).send('Internal server error');
    } else {
      console.log('Email sent successfully:', info.response);
      res.status(200).send('Email sent successfully');
    }
  });
}

// Function to end a task using port 4000
function endTaskOnPort4000() {
  return find('port', 4000).then((list) => {
    if (list.length > 0) {
      const promises = list.map((process) => {
        return new Promise((resolve, reject) => {
          exec(`kill -9 ${process.pid}`, (err, stdout, stderr) => {
            if (err) {
              console.error(`Error killing process ${process.pid} on port 4000: ${stderr}`);
              reject(err);
            } else {
              console.log(`Process ${process.pid} on port 4000 has been terminated`);
              resolve();
            }
          });
        });
      });
      return Promise.all(promises);
    } else {
      console.log('No process found using port 4000');
      return Promise.resolve();
    }
  }).catch((err) => {
    console.error(`Error finding process on port 4000: ${err}`);
    throw err;
  });
}

// Call the function to end the task on port 4000 before starting the server
endTaskOnPort4000().then(() => {
  // Start the server and socket.io on the same port
  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  const io = socketIo(server);

  io.on('connection', (socket) => {
    console.log('A user connected');
    socket.on('disconnect', () => {
      console.log('User disconnected');
    });
  });
}).catch((err) => {
  console.error('Failed to start the server:', err);
});
